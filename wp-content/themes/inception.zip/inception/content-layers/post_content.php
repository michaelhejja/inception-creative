<div class="post-content">
	<div class="Container">
		<?php echo($content_layers[$index]['content']); ?>
	</div>
</div>
